import java.util.Scanner;

class Customer {
    private String customerName;
    private int customerID;
    private int unitsConsumed;

    public Customer(String customerName, int customerID, int unitsConsumed) {
        this.customerName = customerName;
        this.customerID = customerID;
        this.unitsConsumed = unitsConsumed;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getCustomerID() {
        return customerID;
    }

    public int getUnitsConsumed() {
        return unitsConsumed;
    }
}

class BillCalculator {
    private static final double RATE_PER_UNIT = 10.00;

    public double calculateBill(int unitsConsumed) {
        return unitsConsumed * RATE_PER_UNIT;
    }
}

public class ElectricityBill {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Electricity Billing System");

        // Enter customer details
        System.out.print("Enter Customer ID: ");
        int customerID = scanner.nextInt();
        scanner.nextLine();  // Consume newline left-over

        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();

        System.out.print("Enter units consumed: ");
        int unitsConsumed = scanner.nextInt();

        // Create customer object
        Customer customer = new Customer(customerName, customerID, unitsConsumed);

        // Calculate bill
        BillCalculator calculator = new BillCalculator();
        double totalBill = calculator.calculateBill(unitsConsumed);

        // Display bill
        System.out.println("\nElectricity Bill for Customer:");
        System.out.println("Customer ID: " + customer.getCustomerID());
        System.out.println("Customer Name: " + customer.getCustomerName());
        System.out.println("Units Consumed: " + customer.getUnitsConsumed());
        System.out.println("Total Bill: Rs " + totalBill);

        scanner.close();
    }
}
