import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of rooms in the hotel: ");
        int numberOfRooms = scanner.nextInt();
        
        Hotel hotel = new Hotel(numberOfRooms);

        while (true) {
            System.out.println("\nHotel Management System");
            System.out.println("1. Show Available Rooms");
            System.out.println("2. Book a Room");
            System.out.println("3. Check Out a Room");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    hotel.showAvailableRooms();
                    break;
                case 2:
                    System.out.print("Enter room number to book: ");
                    int roomNumberToBook = scanner.nextInt();
                    hotel.bookRoom(roomNumberToBook);
                    break;
                case 3:
                    System.out.print("Enter room number to check out: ");
                    int roomNumberToCheckOut = scanner.nextInt();
                    hotel.checkOutRoom(roomNumberToCheckOut);
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
