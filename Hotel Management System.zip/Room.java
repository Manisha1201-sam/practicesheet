public class Room {
    private int roomNumber;
    private boolean isBooked;

    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
        this.isBooked = false;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void bookRoom() {
        if (!isBooked) {
            isBooked = true;
            System.out.println("Room " + roomNumber + " has been successfully booked.");
        } else {
            System.out.println("Room " + roomNumber + " is already booked.");
        }
    }

    public void checkOut() {
        if (isBooked) {
            isBooked = false;
            System.out.println("Room " + roomNumber + " has been successfully checked out.");
        } else {
            System.out.println("Room " + roomNumber + " is not currently booked.");
        }
    }
}
