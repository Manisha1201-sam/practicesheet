import java.util.ArrayList;

class Library {
    private ArrayList<Book> books;

    public Library() {
        books = new ArrayList<>();
    }

    public void addBook(String title, String author) {
        books.add(new Book(title, author));
        System.out.println("Book '" + title + "' by " + author + " added to the library.");
    }

    public void lendBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.lendBook();
                return;
            }
        }
        System.out.println("Book '" + title + "' not found in the library.");
    }

    public void returnBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.returnBook();
                return;
            }
        }
        System.out.println("Book '" + title + "' not found in the library.");
    }

    public void displayAvailableBooks() {
        boolean booksAvailable = false;
        for (Book book : books) {
            if (!book.isLent()) {
                System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor());
                booksAvailable = true;
            }
        }
        if (!booksAvailable) {
            System.out.println("No available books in the library.");
        }
    }
}

